import pandas as pd
import numpy as np

def load_and_preprocess_data(predictions_file, report_file):
    """
    Load and preprocess two CSV files
    """
    df_pred = pd.read_csv(predictions_file)
    df_report = pd.read_csv(report_file)

    # Standardize column names by stripping whitespace
    df_pred.columns = df_pred.columns.str.strip()
    df_report.columns = df_report.columns.str.strip()

    # Rename columns in report file to match prediction file
    column_mapping = {
        'Distance_Å': 'Distance',
        'Offset_Å': 'Offset',
        'RZ_Å': 'RZ',
        'Angle_°': 'Angle'
    }
    # Only rename columns that actually exist in the DataFrame
    existing_columns = {k: v for k, v in column_mapping.items() if k in df_report.columns}
    df_report = df_report.rename(columns=existing_columns)

    return df_pred, df_report

def extract_protein_residue_with_chain(protein_str):
    """
    Extract residue information from protein string including chain
    Example: "ARG-274-C" -> "ARG-274-C"
    """
    return protein_str

def extract_pdb_id(directory_str):
    """
    Extract PDB ID from Directory string
    Example: "complexes_6QU4_JJ2_6QU4_JJ2_protein_pyrrole" -> "6QU4"
    """
    if isinstance(directory_str, str) and '_' in directory_str:
        parts = directory_str.split('_')
        for part in parts:
            if len(part) == 4 and part.isalnum():
                return part
    return directory_str

def calculate_absolute_errors(df_pred, df_report):
    """
    Calculate absolute errors between two DataFrames using ALL poses
    """
    # Create standardized residue identifiers for merging (including chain)
    df_pred['Protein_Residue_Chain'] = df_pred['Protein'].apply(extract_protein_residue_with_chain)
    df_report['Protein_Residue_Chain'] = df_report['Protein'].apply(extract_protein_residue_with_chain)
    df_pred['PDB_ID'] = df_pred['Directory'].apply(extract_pdb_id)

    # Filter by interaction type if the column exists
    if 'Interaction_Type' in df_pred.columns and 'Interaction_Type' in df_report.columns:
        df_pred = df_pred[df_pred['Interaction_Type'] == 'π-Cation']
        df_report = df_report[df_report['Interaction_Type'] == 'π-Cation']

    # Merge on Protein_Residue_Chain (including chain information)
    merged_df = pd.merge(
        df_pred,
        df_report,
        on=['Protein_Residue_Chain'],
        suffixes=('_pred', '_report'),
        how='inner'
    )

    if merged_df.empty:
        print("Warning: No matching protein residues found after including chain information")
        return pd.DataFrame()

    # Calculate absolute errors
    results = []
    for _, row in merged_df.iterrows():
        distance_error = abs(row['Distance_pred'] - row['Distance_report'])
        offset_error = abs(row['Offset_pred'] - row['Offset_report'])
        rz_error = abs(row['RZ_pred'] - row['RZ_report'])

        results.append({
            'PDB_ID': row['PDB_ID'],
            'Protein_Cation': row['Protein_Residue_Chain'],
            'Distance_Error': distance_error,
            'Offset_Error': offset_error,
            'RZ_Error': rz_error,
            'Pred_Rank': row['Energy_Rank'],
            'Pred_Energy': row['Predicted_Energy']
        })

    # Create DataFrame and round error columns to 2 decimal places
    error_df = pd.DataFrame(results)
    error_cols_to_round = ['Distance_Error', 'Offset_Error', 'RZ_Error']
    error_df[error_cols_to_round] = error_df[error_cols_to_round].round(2)

    return error_df

def calculate_error_statistics(error_df, rank_filter=None):
    """
    Calculate error statistics for specific rank or all poses
    Only include mean, median, max, and std as requested
    """
    if error_df.empty:
        return pd.DataFrame()

    # Filter by rank if specified
    if rank_filter is not None:
        if isinstance(rank_filter, int):
            # Single rank (Top 1)
            filtered_df = error_df[error_df['Pred_Rank'] == rank_filter]
        elif isinstance(rank_filter, list):
            # Multiple ranks (Top 5)
            filtered_df = error_df[error_df['Pred_Rank'].isin(rank_filter)]
        else:
            # All poses
            filtered_df = error_df
    else:
        # All poses
        filtered_df = error_df

    if filtered_df.empty:
        return pd.DataFrame()

    # Calculate only the required statistics: mean, median, max, std
    error_columns = ['Distance_Error', 'Offset_Error', 'RZ_Error']
    
    # Create a clean summary DataFrame with only the requested metrics
    summary_data = {}
    for col in error_columns:
        summary_data[f'{col}_mean'] = filtered_df[col].mean()
        summary_data[f'{col}_median'] = filtered_df[col].median()
        summary_data[f'{col}_max'] = filtered_df[col].max()
        summary_data[f'{col}_std'] = filtered_df[col].std()

    # Create summary DataFrame and transpose for better readability
    summary_df = pd.DataFrame([summary_data])
    
    # Round numeric columns to 2 decimal places
    numeric_cols = summary_df.select_dtypes(include=[np.number]).columns
    summary_df[numeric_cols] = summary_df[numeric_cols].round(2)

    return summary_df, filtered_df

def format_statistics_output(summary_df, title):
    """
    Format the statistics output for clean display
    """
    print(f"\n=== {title} ===")
    if not summary_df.empty:
        # Extract and format the metrics for each error type
        metrics = ['mean', 'median', 'max', 'std']
        error_types = ['Distance_Error', 'Offset_Error', 'RZ_Error']
        
        # Create a clean display DataFrame
        display_data = {}
        for metric in metrics:
            row_data = []
            for error_type in error_types:
                col_name = f"{error_type}_{metric}"
                row_data.append(summary_df[col_name].iloc[0])
            display_data[metric] = row_data
        
        display_df = pd.DataFrame(display_data, index=error_types)
        print(display_df.to_string(float_format='%.2f'))
    else:
        print("No data found")

def main():
    predictions_file = "loose_remained_predictions.csv"
    report_file = "reference_experimental_pication_interactions_report_with_pka_filtered.csv"

    try:
        df_pred, df_report = load_and_preprocess_data(predictions_file, report_file)
        
        # Calculate errors for ALL poses
        print("=== CALCULATING ERRORS FOR ALL POSES ===")
        error_df = calculate_absolute_errors(df_pred, df_report)

        if not error_df.empty:
            # Overall statistics for all poses
            overall_summary, overall_df = calculate_error_statistics(error_df)
            format_statistics_output(overall_summary, "OVERALL ERROR STATISTICS (ALL POSES)")
            print(f"Total number of poses analyzed: {len(overall_df)}")

            # Top 1 statistics
            top1_summary, top1_df = calculate_error_statistics(error_df, rank_filter=1)
            format_statistics_output(top1_summary, "TOP 1 ERROR STATISTICS")
            print(f"Number of Top 1 predictions: {len(top1_df)}")

            # Top 5 statistics (ranks 1-5)
            top5_summary, top5_df = calculate_error_statistics(error_df, rank_filter=[1, 2, 3, 4, 5])
            format_statistics_output(top5_summary, "TOP 5 ERROR STATISTICS")
            print(f"Number of Top 5 predictions: {len(top5_df)}")

        else:
            print("No error data calculated - check input files and merging logic")

    except FileNotFoundError as e:
        print(f"File not found: {e}")
    except Exception as e:
        print(f"Error during processing: {e}")

if __name__ == "__main__":
    main()
