import sys
import os
import glob
import numpy as np
from rdkit import Chem
import warnings
warnings.filterwarnings("ignore", category=UserWarning)

def find_directories(pattern="*_*"):
    """Find all directories matching the pattern"""
    dirs = []
    for item in os.listdir('.'):
        if os.path.isdir(item):
            # Check if directory matches pattern (at least one underscore)
            if '_' in item and not item.startswith('.'):
                dirs.append(item)
    return sorted(dirs)

def find_files_in_directory(directory):
    """Find ligand SDF and protein PDB files in a directory"""
    # First try: exact pattern in the directory
    ligand_pattern1 = os.path.join(directory, f"{directory}_ligand.sdf")
    protein_pattern1 = os.path.join(directory, f"{directory}_protein_protonated.pdb")
    
    # Second try: look for any sdf/pdb files in the directory
    ligand_pattern2 = os.path.join(directory, "*ligand*.sdf")
    protein_pattern2 = os.path.join(directory, "*protein*protonated*.pdb")
    
    # Third try: look for any sdf/pdb files (less strict)
    ligand_pattern3 = os.path.join(directory, "*.sdf")
    protein_pattern3 = os.path.join(directory, "*.pdb")
    
    # Check exact patterns first
    ligand_file = None
    protein_file = None
    
    if os.path.exists(ligand_pattern1):
        ligand_file = ligand_pattern1
    else:
        # Search for SDF files
        sdf_files = glob.glob(ligand_pattern2)
        if not sdf_files:
            sdf_files = glob.glob(ligand_pattern3)
        if sdf_files:
            # Filter to get the most likely ligand file
            for sdf in sdf_files:
                if 'ligand' in sdf.lower() or directory in sdf:
                    ligand_file = sdf
                    break
            if not ligand_file:
                ligand_file = sdf_files[0]  # Take first match
    
    if os.path.exists(protein_pattern1):
        protein_file = protein_pattern1
    else:
        # Search for PDB files
        pdb_files = glob.glob(protein_pattern2)
        if not pdb_files:
            pdb_files = glob.glob(protein_pattern3)
        if pdb_files:
            # Filter to get the most likely protein file
            for pdb in pdb_files:
                if 'protein' in pdb.lower() and 'protonated' in pdb.lower():
                    protein_file = pdb
                    break
            if not protein_file:
                for pdb in pdb_files:
                    if 'protein' in pdb.lower():
                        protein_file = pdb
                        break
            if not protein_file:
                protein_file = pdb_files[0]  # Take first match
    
    return ligand_file, protein_file

def read_ligand_coordinates(sdf_file):
    """Read ligand coordinates from SDF file"""
    try:
        suppl = Chem.SDMolSupplier(sdf_file, removeHs=False)
        mol = next(suppl)
        
        if mol is None:
            raise ValueError(f"Failed to read ligand from {sdf_file}")
        
        # Get all atom coordinates
        coords = []
        for atom in mol.GetAtoms():
            pos = mol.GetConformer().GetAtomPosition(atom.GetIdx())
            coords.append([pos.x, pos.y, pos.z])
        
        return np.array(coords)
    except Exception as e:
        raise ValueError(f"Error reading SDF file {sdf_file}: {str(e)}")

def read_simple_sdf_coordinates(sdf_file):
    """Read coordinates from SDF file without RDKit (fallback)"""
    coords = []
    
    try:
        with open(sdf_file, 'r') as f:
            lines = f.readlines()
        
        atom_count = 0
        atoms_read = 0
        reading_atoms = False
        line_num = 0
        
        for line in lines:
            line_num += 1
            if line_num == 4:  # Line 4 contains counts
                parts = line.strip().split()
                if len(parts) >= 3:
                    try:
                        atom_count = int(parts[0])
                        reading_atoms = True
                    except:
                        reading_atoms = False
                continue
            
            if reading_atoms and atoms_read < atom_count and line_num > 4:
                parts = line.strip().split()
                if len(parts) >= 4:
                    try:
                        x, y, z = float(parts[0]), float(parts[1]), float(parts[2])
                        coords.append([x, y, z])
                        atoms_read += 1
                    except:
                        continue
        
        if len(coords) == 0:
            # Try alternative parsing
            for i, line in enumerate(lines):
                parts = line.strip().split()
                if len(parts) >= 4:
                    try:
                        x, y, z = float(parts[0]), float(parts[1]), float(parts[2])
                        coords.append([x, y, z])
                    except:
                        continue
        
        if len(coords) == 0:
            raise ValueError(f"No coordinates found in SDF file")
        
        return np.array(coords)
    except Exception as e:
        raise ValueError(f"Error reading SDF file {sdf_file}: {str(e)}")

def calculate_buffer_range(coords, buffer_size=8.0):
    """Calculate the buffer range around ligand"""
    coords_array = np.array(coords)
    x_min, y_min, z_min = coords_array.min(axis=0)
    x_max, y_max, z_max = coords_array.max(axis=0)
    
    return (x_min - buffer_size, x_max + buffer_size,
            y_min - buffer_size, y_max + buffer_size,
            z_min - buffer_size, z_max + buffer_size)

def read_protein_residues(pdb_file):
    """Read protein residues from PDB file"""
    residues_dict = {}
    
    try:
        with open(pdb_file, 'r') as f:
            for line in f:
                if line.startswith('ATOM'):
                    try:
                        # Parse PDB line
                        atom_name = line[12:16].strip()
                        res_name = line[17:20].strip()
                        chain = line[21] if line[21] != ' ' else 'A'  # Default chain A
                        res_seq = int(line[22:26].strip())
                        x = float(line[30:38])
                        y = float(line[38:46])
                        z = float(line[46:54])
                        
                        # Use CA atoms for residue position
                        if atom_name == 'CA':
                            res_key = f"{chain}:{res_seq}"
                            residues_dict[res_key] = {
                                'res_name': res_name,
                                'res_seq': res_seq,
                                'chain': chain,
                                'x': x,
                                'y': y,
                                'z': z
                            }
                    except (ValueError, IndexError):
                        continue
    except Exception as e:
        raise ValueError(f"Error reading PDB file {pdb_file}: {str(e)}")
    
    return list(residues_dict.values())

def analyze_directory(directory_id, ligand_file, protein_file, buffer_size=8.0):
    """Analyze a single directory"""
    try:
        if not ligand_file or not os.path.exists(ligand_file):
            raise ValueError(f"Ligand file not found: {ligand_file}")
        if not protein_file or not os.path.exists(protein_file):
            raise ValueError(f"Protein file not found: {protein_file}")
        
        # Read ligand coordinates
        try:
            ligand_coords = read_ligand_coordinates(ligand_file)
        except:
            # Fallback to simple reader if RDKit fails
            ligand_coords = read_simple_sdf_coordinates(ligand_file)
        
        # Calculate buffer range
        buffer_range = calculate_buffer_range(ligand_coords, buffer_size)
        x_min, x_max, y_min, y_max, z_min, z_max = buffer_range
        
        # Read protein residues
        residues = read_protein_residues(protein_file)
        
        # Count residues in buffer
        counts = {'ARG': 0, 'LYS': 0, 'HIS': 0}
        residues_in_buffer = []
        
        for res in residues:
            x, y, z = res['x'], res['y'], res['z']
            res_name = res['res_name']
            
            if (x_min <= x <= x_max and 
                y_min <= y <= y_max and 
                z_min <= z <= z_max):
                
                if res_name == 'ARG':
                    counts['ARG'] += 1
                    residues_in_buffer.append(res)
                elif res_name == 'LYS':
                    counts['LYS'] += 1
                    residues_in_buffer.append(res)
                elif res_name == 'HIS':
                    counts['HIS'] += 1
                    residues_in_buffer.append(res)
        
        return {
            'directory_id': directory_id,
            'ligand_file': os.path.basename(ligand_file),
            'protein_file': os.path.basename(protein_file),
            'ligand_atoms': len(ligand_coords),
            'buffer_range': buffer_range,
            'counts': counts,
            'residues_in_buffer': residues_in_buffer,
            'total_residues': len(residues),
            'error': None
        }
        
    except Exception as e:
        return {
            'directory_id': directory_id,
            'ligand_file': os.path.basename(ligand_file) if ligand_file else "Not found",
            'protein_file': os.path.basename(protein_file) if protein_file else "Not found",
            'error': str(e),
            'counts': {'ARG': 0, 'LYS': 0, 'HIS': 0},
            'residues_in_buffer': []
        }

def main():
    print("=" * 70)
    print("Auto-detecting and analyzing directories with pattern ****_***")
    print("Looking for files inside each directory")
    print("=" * 70)
    
    # Find all directories matching the pattern
    directories = find_directories()
    
    if not directories:
        print("No directories found with pattern ****_***")
        print("Please ensure directories are in format like: 6O0W_A2P, 1ABC_D4E, etc.")
        return
    
    print(f"Found {len(directories)} directories to analyze:")
    for i, dir_name in enumerate(directories, 1):
        print(f"  {i:3d}. {dir_name}")
    print()
    
    all_results = []
    
    for dir_name in directories:
        print(f"\n{'='*70}")
        print(f"Analyzing directory: {dir_name}")
        print(f"{'='*70}")
        
        # Find files
        ligand_file, protein_file = find_files_in_directory(dir_name)
        
        if not ligand_file or not protein_file:
            print(f"  ❌ Missing files in {dir_name}:")
            if not ligand_file:
                print(f"     - Ligand SDF not found")
                # Show what files are in the directory
                sdf_files = glob.glob(os.path.join(dir_name, "*.sdf"))
                if sdf_files:
                    print(f"       Available SDF files: {[os.path.basename(f) for f in sdf_files]}")
            if not protein_file:
                print(f"     - Protein PDB not found")
                # Show what files are in the directory
                pdb_files = glob.glob(os.path.join(dir_name, "*.pdb"))
                if pdb_files:
                    print(f"       Available PDB files: {[os.path.basename(f) for f in pdb_files]}")
            all_results.append({
                'directory_id': dir_name,
                'error': f"Missing files: ligand={ligand_file is None}, protein={protein_file is None}",
                'counts': {'ARG': 0, 'LYS': 0, 'HIS': 0}
            })
            continue
        
        print(f"  ✓ Ligand file: {os.path.basename(ligand_file)}")
        print(f"  ✓ Protein file: {os.path.basename(protein_file)}")
        
        # Analyze the directory
        result = analyze_directory(dir_name, ligand_file, protein_file, buffer_size=8.0)
        
        if result['error']:
            print(f"  ❌ Error: {result['error']}")
        else:
            counts = result['counts']
            buffer_range = result['buffer_range']
            x_min, x_max, y_min, y_max, z_min, z_max = buffer_range
            
            print(f"  ✓ Ligand atoms: {result['ligand_atoms']}")
            print(f"  ✓ Buffer range (Å):")
            print(f"     X: [{x_min:7.2f}, {x_max:7.2f}]")
            print(f"     Y: [{y_min:7.2f}, {y_max:7.2f}]")
            print(f"     Z: [{z_min:7.2f}, {z_max:7.2f}]")
            print(f"  ✓ Residues in 8Å buffer:")
            print(f"     ARG: {counts['ARG']:2d}")
            print(f"     LYS: {counts['LYS']:2d}")
            print(f"     HIS: {counts['HIS']:2d}")
            print(f"     TOTAL: {sum(counts.values()):2d}")
            
            if result['residues_in_buffer']:
                print(f"  ✓ Residue list ({len(result['residues_in_buffer'])} residues):")
                residues = sorted(result['residues_in_buffer'], key=lambda x: (x['chain'], x['res_seq']))
                residue_strs = []
                for res in residues:
                    residue_strs.append(f"{res['chain']}:{res['res_seq']}{res['res_name']}")
                
                # Print residues in a compact format
                for i in range(0, len(residue_strs), 8):
                    print(f"     {' '.join(residue_strs[i:i+8])}")
        
        all_results.append(result)
    
    
    # Save detailed results
    save_results_to_csv(all_results)
    
    print(f"\n{'='*70}")
    print("Analysis complete! Check true_negative_counts.csv for details.")
    print(f"{'='*70}")


def save_results_to_csv(results):
    """Save results to CSV file"""
    import csv
    
    with open('true_negative_counts.csv', 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['Directory', 'ARG', 'LYS', 'HIS', 'TOTAL', 'Ligand_Atoms', 'Ligand_File', 'Protein_File', 'Status', 'Error'])
        
        for result in results:
            if result.get('error') is None:
                counts = result['counts']
                total = sum(counts.values())
                writer.writerow([
                    result['directory_id'],
                    counts['ARG'],
                    counts['LYS'],
                    counts['HIS'],
                    total,
                    result.get('ligand_atoms', 'N/A'),
                    result.get('ligand_file', 'N/A'),
                    result.get('protein_file', 'N/A'),
                    'SUCCESS',
                    ''
                ])
            else:
                writer.writerow([
                    result['directory_id'],
                    0, 0, 0, 0,
                    'N/A',
                    result.get('ligand_file', 'N/A'),
                    result.get('protein_file', 'N/A'),
                    'FAILED',
                    result.get('error', 'Unknown error')
                ])
    


if __name__ == "__main__":
    main()

