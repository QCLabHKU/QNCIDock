#!/usr/bin/env python3
import pandas as pd
import numpy as np
import re
from pathlib import Path

def extract_core_pdb_id(s):
    """Extract core PDB-ligand ID like '8KCO_N60' from strings like 'complexes_8KCO_N60_exhaust50'."""
    s = str(s)
    match = re.search(r'([A-Z0-9]{4}_[A-Z0-9]+)', s.upper())
    if match:
        return match.group(1)
    return s.split('_')[0].strip()

def extract_residue_id(protein_str):
    """Extract normalized residue ID: 'ARG-102-A' → 'ARG102'."""
    s = str(protein_str).strip()
    match = re.search(r'([A-Z]{3})\D*(\d+)', s.upper())
    if match:
        res = match.group(1)
        num = match.group(2)
        if res in {'ARG', 'LYS', 'HIS'}:
            return f"{res}{num}"
    return None
def apply_ranking(df_pred):
    """
    Filter predictions using residue-specific ranking rules:
    - ARG residues: dihedral-angle binning (2° bins, 45 bins total).
    - HIS residues: keep the top 50% by Energy_Rank.
    - LYS residues: keep the top 12% by Energy_Rank.
    """
    df = df_pred.copy()
    df['_ResType'] = df['Protein'].apply(
        lambda x: extract_residue_id(x)[:3] if extract_residue_id(x) else None
    )

    filtered_rows = []

    # ARG: dihedral-angle binning
    arg_subset = df[df['_ResType'] == 'ARG'].copy()
    if not arg_subset.empty and 'Dihedral_Angle' in df.columns:
        bin_size = 2
        dihedral_bins = 45
        # First 10 bins have decreasing percentages, remaining bins fixed at 10%
        top_percent_per_bin = [60, 55, 50, 45, 40, 35, 30, 25, 20, 15] + [10] * 35

        for bin_idx in range(dihedral_bins):
            bin_start = bin_idx * bin_size
            bin_end = (bin_idx + 1) * bin_size if bin_idx < dihedral_bins - 1 else 90

            bin_subset = arg_subset[
                (arg_subset['Dihedral_Angle'] >= bin_start) &
                (arg_subset['Dihedral_Angle'] < bin_end if bin_idx < dihedral_bins - 1
                 else arg_subset['Dihedral_Angle'] <= bin_end)
            ].copy()

            if not bin_subset.empty:
                pct = top_percent_per_bin[bin_idx]
                n_total = len(bin_subset)
                n_keep = max(1, min(int(n_total * (pct / 100)), n_total))
                bin_sorted = bin_subset.sort_values('Energy_Rank')
                filtered_rows.append(bin_sorted.head(n_keep))
    else:
        if not arg_subset.empty:
            filtered_rows.append(arg_subset)

    # HIS: keep top 50%, LYS: keep top 12%
    for res, pct in [('HIS', 50), ('LYS', 12)]:
        subset = df[df['_ResType'] == res].copy()
        if not subset.empty:
            n_keep = max(1, int(len(subset) * pct / 100))
            filtered_rows.append(subset.nsmallest(n_keep, 'Energy_Rank'))

    return pd.concat(filtered_rows, ignore_index=True) if filtered_rows else df.iloc[0:0]

def load_buffer_analysis(buffer_file="buffer_analysis_summary.csv"):
    """Load buffer analysis results and compute total possible binders."""
    if not Path(buffer_file).exists():
        print(f"Warning: Buffer analysis file not found: {buffer_file}")
        return {}
    
    try:
        df_buffer = pd.read_csv(buffer_file)
        df_buffer = df_buffer[df_buffer['Status'] == 'SUCCESS'].copy()
        
        buffer_data = {}
        for _, row in df_buffer.iterrows():
            pdb_id = row['Directory']
            total_possible = {
                'ARG': int(row['ARG']),
                'LYS': int(row['LYS']), 
                'HIS': int(row['HIS']),
                'ALL': int(row['ARG']) + int(row['LYS']) + int(row['HIS'])
            }
            buffer_data[pdb_id] = total_possible
            
        return buffer_data
    except Exception as e:
        print(f"Error loading buffer analysis: {e}")
        return {}

def calculate_metrics(report_file, predictions_file, buffer_file="buffer_analysis_summary.csv"):
    """Calculate metrics focusing on TN, FPR after filtering, and recovery rate after filtering."""
    buffer_data = load_buffer_analysis(buffer_file)
    
    df_report = pd.read_csv(report_file)
    df_pred = pd.read_csv(predictions_file)

    df_report['_CorePDB'] = df_report['Directory'].apply(extract_core_pdb_id)
    df_pred['_CorePDB'] = df_pred['PDB_ID'].apply(extract_core_pdb_id)
    df_report['_ResID'] = df_report['Protein'].apply(extract_residue_id)
    df_pred['_ResID'] = df_pred['Protein'].apply(extract_residue_id)
    df_report['_ResType'] = df_report['_ResID'].str[:3]
    df_pred['_ResType'] = df_pred['_ResID'].str[:3]

    valid_report = df_report.dropna(subset=['_CorePDB', '_ResID', '_ResType'])
    valid_pred = df_pred.dropna(subset=['_CorePDB', '_ResID', '_ResType'])

    # Remove duplicate experimental references
    df_report_unique = valid_report.drop_duplicates(subset=['_CorePDB', '_ResID'])
    
    # Create reference sets - unique interactions only
    ref_by_type = {
        'ARG': set(zip(df_report_unique[df_report_unique['_ResType'] == 'ARG']['_CorePDB'],
                       df_report_unique[df_report_unique['_ResType'] == 'ARG']['_ResID'])),
        'LYS': set(zip(df_report_unique[df_report_unique['_ResType'] == 'LYS']['_CorePDB'],
                       df_report_unique[df_report_unique['_ResType'] == 'LYS']['_ResID'])),
        'ALL': set(zip(df_report_unique[df_report_unique['_ResType'].isin(['ARG', 'LYS'])]['_CorePDB'],
                       df_report_unique[df_report_unique['_ResType'].isin(['ARG', 'LYS'])]['_ResID']))
    }

    # Filter predictions and remove duplicates
    df_pred_filtered = apply_ranking(valid_pred)
    df_pred_unique = df_pred_filtered.drop_duplicates(subset=['_CorePDB', '_ResID'])
    
    pred_set_after = set(zip(df_pred_unique['_CorePDB'], df_pred_unique['_ResID']))
    
    pred_by_type_after = {
        'ARG': set(zip(df_pred_unique[df_pred_unique['_ResType'] == 'ARG']['_CorePDB'],
                       df_pred_unique[df_pred_unique['_ResType'] == 'ARG']['_ResID'])),
        'LYS': set(zip(df_pred_unique[df_pred_unique['_ResType'] == 'LYS']['_CorePDB'],
                       df_pred_unique[df_pred_unique['_ResType'] == 'LYS']['_ResID'])),
        'ALL': set(zip(df_pred_unique[df_pred_unique['_ResType'].isin(['ARG', 'LYS'])]['_CorePDB'],
                       df_pred_unique[df_pred_unique['_ResType'].isin(['ARG', 'LYS'])]['_ResID']))
    }

    # Calculate metrics
    metrics = {}
    
    for typ in ['ALL', 'ARG', 'LYS']:
        ref_set = ref_by_type[typ]
        pred_after = pred_by_type_after[typ]
        
        tp_after = len(ref_set & pred_after)
        fp_after = len(pred_after - ref_set)
        fn_after = len(ref_set - pred_after)
        total_ref = len(ref_set)
        
        # Calculate True Negatives from buffer data
        tn_after = 0
        total_possible = 0
        
        if buffer_data:
            for pdb_id, possible_counts in buffer_data.items():
                if typ == 'ALL':
                    n_possible = possible_counts['ALL']
                else:
                    n_possible = possible_counts[typ]
                
                pred_count = sum(1 for item in pred_after if item[0] == pdb_id and (typ == 'ALL' or item[1].startswith(typ)))
                tp_count = sum(1 for ref_item in ref_set if ref_item[0] == pdb_id and ref_item in pred_after)
                fp_count = pred_count - tp_count
                tn_count = n_possible - tp_count - fp_count
                
                tn_after += max(0, tn_count)
                total_possible += n_possible
        
        # Store metrics
        metrics[f'{typ.lower()}_total'] = total_ref
        metrics[f'{typ.lower()}_tp_after'] = tp_after
        metrics[f'{typ.lower()}_fp_after'] = fp_after
        metrics[f'{typ.lower()}_fn_after'] = fn_after
        metrics[f'{typ.lower()}_tn_after'] = tn_after
        metrics[f'{typ.lower()}_total_possible'] = total_possible
        
        # Recovery rate after filtering
        recovery_after = 100 * tp_after / total_ref if total_ref > 0 else 0.0
        metrics[f'{typ.lower()}_recovery_after'] = recovery_after
        
        # False Positive Rate after filtering (as percentage)
        fpr_after = 100 * fp_after / (fp_after + tn_after) if (fp_after + tn_after) > 0 else 0.0
        metrics[f'{typ.lower()}_fpr_after'] = fpr_after
    
    return metrics

def print_report(metrics):
    """Print a focused report with requested metrics only."""
    print("=" * 70)
    print("π-CATION INTERACTION PREDICTION - FOCUSED METRICS")
    print("=" * 70)
    
    print("\nRECOVERY RATE AFTER FILTERING (%):")
    print("-" * 70)
    print(f"{'Category':<15} {'Recovery Rate':>15} {'Total Experimental':>18} {'True Positives':>15}")
    print("-" * 70)
    
    for typ in ['ALL', 'ARG', 'LYS']:
        key = typ.lower()
        recovery = metrics.get(f'{key}_recovery_after', 0)
        total = metrics.get(f'{key}_total', 0)
        tp = metrics.get(f'{key}_tp_after', 0)
        print(f"{typ:<15} {recovery:>14.1f}% {total:>18,d} {tp:>15,d}")
    
    print("\nFALSE POSITIVE RATE AFTER FILTERING (%):")
    print("-" * 70)
    print(f"{'Category':<15} {'FPR':>15} {'False Positives':>16} {'True Negatives':>15}")
    print("-" * 70)
    
    for typ in ['ALL', 'ARG', 'LYS']:
        key = typ.lower()
        fpr = metrics.get(f'{key}_fpr_after', 0)
        fp = metrics.get(f'{key}_fp_after', 0)
        tn = metrics.get(f'{key}_tn_after', 0)
        print(f"{typ:<15} {fpr:>14.2f}% {fp:>16,d} {tn:>15,d}")
    
    print("\nSUMMARY:")
    print("-" * 70)
    print(f"Total possible binders (ARG + LYS) across all complexes: {metrics.get('all_total_possible', 0):,}")
    print(f"Total experimental interactions (ARG + LYS): {metrics.get('all_total', 0):,}")
    print(f"Recovery rate (ALL) after filtering: {metrics.get('all_recovery_after', 0):.1f}%")
    print(f"False Positive Rate (ALL) after filtering: {metrics.get('all_fpr_after', 0):.2f}%")

def main():
    report_file = "reference_experimental_pication_interactions_report_with_pka_filtered.csv"
    predictions_file = "predictions_with_energy_ranked.csv"
    buffer_file = "true_negative_counts.csv"
    
    metrics = calculate_metrics(report_file, predictions_file, buffer_file)
    print_report(metrics)

if __name__ == "__main__":
    main()

