import pandas as pd
import re

def extract_core_pdb_id(s):
    """Extract core PDB ID matching original logic"""
    s = str(s)
    match = re.search(r'([A-Z0-9]{4}_[A-Z0-9]+)', s.upper())
    if match:
        return match.group(1)
    return s.split('_')[0].split('/')[0].split('\\')[0].strip()

def extract_residue_id(protein_str):
    """Strict residue extraction matching original criteria"""
    s = str(protein_str).strip()
    match = re.search(r'([A-Z]{3})\D*(\d+)', s.upper())
    if match:
        res = match.group(1)
        num = match.group(2)
        if res in {'ARG', 'LYS', 'HIS'}:
            return f"{res}{num}"
    return None

def format_percentage(num, den):
    """Format results as fraction with percentage"""
    if den > 0:
        return f"{num}/{den} ({(num/den)*100:.1f}%)"
    return "0/0 (0.0%)"

def main():
    # Load data
    ref_df = pd.read_csv('reference_experimental_pication_interactions_report_with_pka_filtered.csv')
    pred_df = pd.read_csv('model_interactions.csv')

    # Count ALL reference interactions (full dataset)
    full_ref_counts = {
        'ARG': set(),
        'LYS': set(),
        'HIS': set(),
        'complexes': set()
    }

    # Track all unique reference interactions
    for _, row in ref_df.iterrows():
        core_id = extract_core_pdb_id(row['Directory'])
        resid = extract_residue_id(row['Protein'])
        if not core_id or not resid:
            continue
            
        full_ref_counts['complexes'].add(core_id)
        interaction_key = f"{core_id}_{resid}"
        
        if resid.startswith('ARG'):
            full_ref_counts['ARG'].add(interaction_key)
        elif resid.startswith('LYS'):
            full_ref_counts['LYS'].add(interaction_key)
        elif resid.startswith('HIS'):
            full_ref_counts['HIS'].add(interaction_key)

    # Calculate total unique interactions
    total_unique_interactions = (len(full_ref_counts['ARG']) + 
                                len(full_ref_counts['LYS']) + 
                                len(full_ref_counts['HIS']))

    # Process reference data for comparison
    ref_by_pdb = {}
    for _, row in ref_df.iterrows():
        core_id = extract_core_pdb_id(row['Directory'])
        resid = extract_residue_id(row['Protein'])
        if not core_id or not resid:
            continue
            
        if core_id not in ref_by_pdb:
            ref_by_pdb[core_id] = {'all': set(), 'ARG': set(), 'LYS': set(), 'HIS': set()}
            
        interaction_key = f"{core_id}_{resid}"
        ref_by_pdb[core_id]['all'].add(interaction_key)
        
        if resid.startswith('ARG'):
            ref_by_pdb[core_id]['ARG'].add(interaction_key)
        elif resid.startswith('LYS'):
            ref_by_pdb[core_id]['LYS'].add(interaction_key)
        elif resid.startswith('HIS'):
            ref_by_pdb[core_id]['HIS'].add(interaction_key)

    # Process predictions
    model_by_pdb_rank = {}
    vina_by_pdb_rank = {}

    for _, row in pred_df.iterrows():
        core_id = extract_core_pdb_id(row['PDB_ID'])
        resid = extract_residue_id(row['Protein'])
        if not core_id or not resid:
            continue
            
        mr = int(row['Model_Rank'])
        vr = int(row['Vina_Rank'])
        rmsd = float(row['RMSD'])

        # Model predictions (Top-8)
        if mr <= 8:
            if core_id not in model_by_pdb_rank:
                model_by_pdb_rank[core_id] = {}
            if mr not in model_by_pdb_rank[core_id]:
                model_by_pdb_rank[core_id][mr] = []
            model_by_pdb_rank[core_id][mr].append((resid, rmsd, mr))

        # Vina predictions (Top-8)
        if vr <= 8:
            if core_id not in vina_by_pdb_rank:
                vina_by_pdb_rank[core_id] = {}
            if vr not in vina_by_pdb_rank[core_id]:
                vina_by_pdb_rank[core_id][vr] = []
            vina_by_pdb_rank[core_id][vr].append((resid, rmsd, vr))

    # Get common complexes for comparison
    common_pdbs = set(ref_by_pdb.keys()) & (set(model_by_pdb_rank.keys()) | set(vina_by_pdb_rank.keys()))

    # Initialize counters for both Top-2 and Top-8
    results = {
        'vina_top2': {'all': set(), 'ARG': set(), 'LYS': set(), 'HIS': set()},
        'vina_top8': {'all': set(), 'ARG': set(), 'LYS': set(), 'HIS': set()},
        'our_method_top2': {'all': set(), 'ARG': set(), 'LYS': set(), 'HIS': set()},
        'our_method_top8': {'all': set(), 'ARG': set(), 'LYS': set(), 'HIS': set()}
    }

    def get_items_up_to_rank(data_dict, pdb, max_rank):
        """Get items from ranks 1 to max_rank"""
        result = []
        if pdb in data_dict:
            for r in range(1, max_rank + 1):
                if r in data_dict[pdb]:
                    result.extend(data_dict[pdb][r])
        return sorted(result, key=lambda x: x[2])  # Sort by rank

    def get_unique_poses(items, target_count):
        """Select unique poses based on residue-RMSD"""
        seen = set()
        selected = []
        for resid, rmsd, rank in items:
            key = (resid, round(rmsd, 6))
            if key not in seen and len(selected) < target_count:
                selected.append(resid)
                seen.add(key)
        return selected

    # Evaluation logic
    for pdb in common_pdbs:
        ref = ref_by_pdb[pdb]

        # Vina Top-2 evaluation
        vina_items = get_items_up_to_rank(vina_by_pdb_rank, pdb, 2)
        v_set = get_unique_poses(vina_items, 2)
        for resid in v_set:
            interaction_key = f"{pdb}_{resid}"
            if interaction_key in ref['all']:
                results['vina_top2']['all'].add(interaction_key)
                if resid.startswith('ARG'):
                    results['vina_top2']['ARG'].add(interaction_key)
                elif resid.startswith('LYS'):
                    results['vina_top2']['LYS'].add(interaction_key)
                elif resid.startswith('HIS'):
                    results['vina_top2']['HIS'].add(interaction_key)

        # Vina Top-8 evaluation
        vina_items = get_items_up_to_rank(vina_by_pdb_rank, pdb, 8)
        v_set = get_unique_poses(vina_items, 8)
        for resid in v_set:
            interaction_key = f"{pdb}_{resid}"
            if interaction_key in ref['all']:
                results['vina_top8']['all'].add(interaction_key)
                if resid.startswith('ARG'):
                    results['vina_top8']['ARG'].add(interaction_key)
                elif resid.startswith('LYS'):
                    results['vina_top8']['LYS'].add(interaction_key)
                elif resid.startswith('HIS'):
                    results['vina_top8']['HIS'].add(interaction_key)

        # Our Method Top-2 evaluation (model top-1 + vina top-1 = 2 poses)
        model_items = get_items_up_to_rank(model_by_pdb_rank, pdb, 1)
        vina_items = get_items_up_to_rank(vina_by_pdb_rank, pdb, 1)
        c_set = get_unique_poses(model_items + vina_items, 2)
        for resid in c_set:
            interaction_key = f"{pdb}_{resid}"
            if interaction_key in ref['all']:
                results['our_method_top2']['all'].add(interaction_key)
                if resid.startswith('ARG'):
                    results['our_method_top2']['ARG'].add(interaction_key)
                elif resid.startswith('LYS'):
                    results['our_method_top2']['LYS'].add(interaction_key)
                elif resid.startswith('HIS'):
                    results['our_method_top2']['HIS'].add(interaction_key)

        # Our Method Top-8 evaluation (model top-4 + vina top-4 = 8 poses)
        model_items = get_items_up_to_rank(model_by_pdb_rank, pdb, 4)
        vina_items = get_items_up_to_rank(vina_by_pdb_rank, pdb, 4)
        c_set = get_unique_poses(model_items + vina_items, 8)
        for resid in c_set:
            interaction_key = f"{pdb}_{resid}"
            if interaction_key in ref['all']:
                results['our_method_top8']['all'].add(interaction_key)
                if resid.startswith('ARG'):
                    results['our_method_top8']['ARG'].add(interaction_key)
                elif resid.startswith('LYS'):
                    results['our_method_top8']['LYS'].add(interaction_key)
                elif resid.startswith('HIS'):
                    results['our_method_top8']['HIS'].add(interaction_key)

    # Get counts of matched unique interactions
    vina_top2_all = len(results['vina_top2']['all'])
    vina_top2_ARG = len(results['vina_top2']['ARG'])
    vina_top2_LYS = len(results['vina_top2']['LYS'])
    vina_top2_HIS = len(results['vina_top2']['HIS'])
    
    vina_top8_all = len(results['vina_top8']['all'])
    vina_top8_ARG = len(results['vina_top8']['ARG'])
    vina_top8_LYS = len(results['vina_top8']['LYS'])
    vina_top8_HIS = len(results['vina_top8']['HIS'])
    
    our_method_top2_all = len(results['our_method_top2']['all'])
    our_method_top2_ARG = len(results['our_method_top2']['ARG'])
    our_method_top2_LYS = len(results['our_method_top2']['LYS'])
    our_method_top2_HIS = len(results['our_method_top2']['HIS'])
    
    our_method_top8_all = len(results['our_method_top8']['all'])
    our_method_top8_ARG = len(results['our_method_top8']['ARG'])
    our_method_top8_LYS = len(results['our_method_top8']['LYS'])
    our_method_top8_HIS = len(results['our_method_top8']['HIS'])

    # Display results with full reference counts as denominators
    print("=" * 85)
    print("PICATION INTERACTION RECOVERY RATE COMPARISON")
    print(f"                      (Vina vs Our Method - {len(common_pdbs)} Common Complexes)")
    print("=" * 85)
    print(f"Reference Complexes: {len(full_ref_counts['complexes'])}")
    print(f"Unique ARG Interactions: {len(full_ref_counts['ARG'])}")
    print(f"Unique LYS Interactions: {len(full_ref_counts['LYS'])}")
    print(f"Unique HIS Interactions: {len(full_ref_counts['HIS'])}")
    print(f"Total Unique Interactions: {total_unique_interactions}")
    print(f"Common Complexes: {len(common_pdbs)}")
    print("=" * 85)
    print()

    print(f"{'Poses Evaluated':<15} {'Cationic Amino Acid':<20} {'Vina Top-2':<25} {'Our Method Top-2':<25} {'Vina Top-8':<25} {'Our Method Top-8':<25}")
    print("-" * 125)

    # Print results for all categories
    print(f"{'Top-2/Top-8':<15} {'All':<20} {format_percentage(vina_top2_all, total_unique_interactions):<25} {format_percentage(our_method_top2_all, total_unique_interactions):<25} {format_percentage(vina_top8_all, total_unique_interactions):<25} {format_percentage(our_method_top8_all, total_unique_interactions):<25}")
    print(f"{'':<15} {'ARG':<20} {format_percentage(vina_top2_ARG, len(full_ref_counts['ARG'])):<25} {format_percentage(our_method_top2_ARG, len(full_ref_counts['ARG'])):<25} {format_percentage(vina_top8_ARG, len(full_ref_counts['ARG'])):<25} {format_percentage(our_method_top8_ARG, len(full_ref_counts['ARG'])):<25}")
    print(f"{'':<15} {'LYS':<20} {format_percentage(vina_top2_LYS, len(full_ref_counts['LYS'])):<25} {format_percentage(our_method_top2_LYS, len(full_ref_counts['LYS'])):<25} {format_percentage(vina_top8_LYS, len(full_ref_counts['LYS'])):<25} {format_percentage(our_method_top8_LYS, len(full_ref_counts['LYS'])):<25}")

    if len(full_ref_counts['HIS']) > 0:
        print(f"{'':<15} {'HIS':<20} {format_percentage(vina_top2_HIS, len(full_ref_counts['HIS'])):<25} {format_percentage(our_method_top2_HIS, len(full_ref_counts['HIS'])):<25} {format_percentage(vina_top8_HIS, len(full_ref_counts['HIS'])):<25} {format_percentage(our_method_top8_HIS, len(full_ref_counts['HIS'])):<25}")
    else:
        print(f"{'':<15} {'HIS':<20} {'No cationic HIS in this dataset':<25} {'No cationic HIS in this dataset':<25} {'No cationic HIS in this dataset':<25} {'No cationic HIS in this dataset':<25}")

    print("=" * 125)
    print("\nNote: Recovery rates calculated against full unique reference counts")

if __name__ == "__main__":
    main()

